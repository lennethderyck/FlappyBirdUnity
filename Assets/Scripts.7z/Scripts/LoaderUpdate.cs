﻿using UnityEngine;

public class LoaderUpdate : MonoBehaviour
{
    private void Update()
    {
        Loader.LoadTargetScene();
    }
}
